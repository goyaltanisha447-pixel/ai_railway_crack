"""
models/crack_detection_model.py
Defines and loads the CNN used for track-crack classification.
Train separately (e.g. in a notebook/Colab) and drop the resulting
.h5 weights file at the path in config.MODEL_PATH.
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models


IMG_SIZE = (128, 128)


def build_model():
    """Simple CNN architecture: crack vs no-crack binary classifier."""
    model = models.Sequential([
        layers.Input(shape=(IMG_SIZE[0], IMG_SIZE[1], 3)),
        layers.Rescaling(1.0 / 255),

        layers.Conv2D(16, 3, activation="relu"),
        layers.MaxPooling2D(),

        layers.Conv2D(32, 3, activation="relu"),
        layers.MaxPooling2D(),

        layers.Conv2D(64, 3, activation="relu"),
        layers.MaxPooling2D(),

        layers.Flatten(),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid"),  # 0 = no crack, 1 = crack
    ])

    model.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )
    return model


def load_trained_model(model_path):
    """Loads a trained .h5 model if it exists, else returns a fresh
    (untrained) model so the pipeline can still run end-to-end."""
    if os.path.exists(model_path):
        return tf.keras.models.load_model(model_path)
    print(f"[WARN] No trained model found at {model_path}. "
          f"Using an untrained model — predictions will be meaningless "
          f"until you train and save weights there.")
    return build_model()


def preprocess_frame(frame):
    """Resize + batch a raw camera frame (numpy array) for inference."""
    img = tf.image.resize(frame, IMG_SIZE)
    img = tf.expand_dims(img, axis=0)
    return img


if __name__ == "__main__":
    m = build_model()
    m.summary()
